<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php echo validation_errors();?>
<div class="container">
	<h2>Registration</h2>
  	<form method="post" action="<?php echo base_url();?>index.php/dashboard/patientsRecord/RecordCreation/updateView/<?php echo $regNo;?>">
	    <div class="form-group row">
	    	<div class="col-xs-10">
		    	<label for="regNo">Register number:</label>
		    	<input class="form-control" id="regNo" name="regNo" type="text" readonly="true" value="<?php echo $regNo; ?>">
		    	<input type="text" id="hiddenRegNo" name="hiddenRegNo" value="<?php echo $hiddenRegNo;?>">
		  	</div>
		  	<div class="col-xs-2">
		    	<button type="button" class="btn btn-primary" id="opedit" data-edit="true">
		    		<i class="fa fa-pencil" style="font-size:24px"></i>
		    	</button>
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="patientName">Patient name</label>
		    	<input class="form-control" id="patientName" name="patientName" type="text" value="<?php echo $patientName; ?>">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="dob">Date Of Birth</label>
		    	<input class="form-control" id="dob" type="text">
		  	</div>
		  	<div class="col-xs-2">
		    	<label for="age">Age</label>
		    	<!-- <select class="form-control" id="age">
				    <option value="1">1</option>
  				</select> -->
  				<input class="form-control" id="age" type="text" readonly="">
		  	</div>
		  	<div class="col-xs-2">
		    	<label for="ex3">Gender</label>
		    	<select class="form-control" id="age">
				    <option value="" selected="" disabled="">--select any--</option>
				    <option value="Male">Male</option>
				    <option value="Female">Female</option>
				    <option value="Others">Others</option>
  				</select>
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">House</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Place</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Post Office</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="state">State</label>
		    	<select class="form-control" id="state">
				    <option value="" selected="" disabled="">--select any--</option>
				    <option value="7">Kerala</option>
  				</select>
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Distric</label>
		    	<select class="form-control" id="state">
				    <option value="" selected="" disabled="">--select any--</option>
				    <option value="7">Ernakulam</option>
  				</select>
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Pin</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Contact No</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Parent /Guardian Name</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Emergency Contact No</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Category</label>
		    	<input class="form-control" id="ex3" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="regDate">Registration Date</label>
		    	<input class="form-control" id="regDate" type="text">
		  	</div>
		  	<div class="col-xs-4">
		    	<label for="ex1">Remarks</label>
		    	<textarea class="form-control" rows="5" id="comment"></textarea>
		  	</div>
		</div>
	    <button type="submit" class="btn btn-success pull-right">Submit</button>
  	</form>
</div>
<script type="text/javascript" src="http://chavaradarsan.com/chavaraAdmissionsApplyOnline/assets/js/bootstrap-datepicker.min.js"></script>
</body> 
</html>
<script type="text/javascript">
	$(document).ready(function(){
		$( "#dob,#regDate" ).datepicker( {format: 'yyyy-mm-dd'} );

		$( "#dob" ).on( 'change', function(){
			var age = 0, currentYear;

			age = $(this).val().split('-')[0];
			currentYear = new Date();
			currentYear = currentYear.getFullYear();
			age = currentYear - age;

			// console.log(age);
			$('#age').val(age);
		});

		$('#opedit').on('click',function(){


			if( $(this).data('edit') ){

				$('#regNo').attr('readonly',false);
				$(this).data('edit',false);
				$(this).empty();
				$(this).html('<i class="fa fa-check"></i>')

			}
			else{
				$('#regNo').attr('readonly',true);
				$(this).data('edit',true);
				$(this).empty();
				$(this).html('<i class="fa fa-pencil" style="font-size:24px"></i>');


				if( $('#regNo').val()!=$('#hiddenRegNo').val() ){

					$.ajax({
						url:'<?php echo base_url();?>index.php/dashboard/patientsRecord/RecordCreation/checkRegNoAlreadyExistsAjax/',
						method:'POST',
						data:{regNo:$('#regNo').val()},
						success: function(data){
							if(data){
								alert('This register number already exists!');
								$('#regNo').val($('#hiddenRegNo').val());
							}
						}
					});
				}

			}
		});
	});
</script>
